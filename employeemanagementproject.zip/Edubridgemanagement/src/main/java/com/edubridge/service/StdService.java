package com.edubridge.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.entity.Student;
import com.edubridge.userrepository.Userrepo;
@Service
public class StdService
{
	@Autowired
	private Userrepo repo;
public void addstd(Student s)
{
	repo.save(s);
}
public List<Student> getAllStd()
{
	
	return repo.findAll();
}
public  Student getStdbyId(int id)
{
	Optional<Student> s=repo.findById(id);
	if(s.isPresent()) 
	{
		return s.get();
	}
	return null;
}
public void deletestd(int id) 
{
	repo.deleteById(id);
}

}